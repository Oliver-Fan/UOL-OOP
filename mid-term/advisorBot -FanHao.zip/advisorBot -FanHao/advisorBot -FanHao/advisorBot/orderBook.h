#pragma once
#include "orderBookEntry.h"
#include "csvReader.h"
#include <string>
#include <vector>

class orderBook
{
    public:
        orderBook(std::string filename);
        std::vector<std::string> getKnownProducts();
        std::vector<std::string> getKnownTimes();

        std::vector<orderBookEntry> getOrders(orderBookType type,
                                              std::string product,
                                              std::string timestep);

        std::vector<orderBookEntry> AdvisorBot(std::string product, orderBookType type);

        /** returns the earliest time in the orderbook*/
        std::string getEarliestTime();


         /** returns the next time after the
     * sent time in the orderbook
     * If there is no next timestep, wraps around to the start
     * */
        std::string getNextTime(std::string timestep);
        //std::string getPreviousTime(std::string timestep);

        static double getHighPrice(std::vector<orderBookEntry>& orders);
        static double getLowPrice(std::vector<orderBookEntry>& orders);
        std::vector<double> getCommonPrice(std::vector<orderBookEntry>& orders);


        static double getTotalOrder(std::vector<orderBookEntry> & orders);
        static double getTotalVector(std::vector<double> Total);
        double getAverage(std::vector<double> vals);

    private:
        std::vector<orderBookEntry> orders;

};