#pragma once

#include <string>

enum class orderBookType{bid, ask, unknown, asksale, bidsale};

class orderBookEntry
{
    public:

        orderBookEntry( double _price,
                        double _amount,
                        std::string _timestep,
                        std::string _product,
                        orderBookType _orderType,
                        std::string username= "dataset");

        static orderBookType strToOBT(std::string s);

        static bool compareByTimestep(orderBookEntry& e1, orderBookEntry& e2)
        {
            return e1.timestep < e2.timestep;
        }  
        static bool compareByPriceAsc(orderBookEntry& e1, orderBookEntry& e2)
        {
            return e1.price < e2.price;
        }
         static bool compareByPriceDesc(orderBookEntry& e1, orderBookEntry& e2)
        {
            return e1.price > e2.price;
        }

        double price;
        double amount;
        std::string timestep;
        std::string product;
        orderBookType orderType;
        std::string username;
};