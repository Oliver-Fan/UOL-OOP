#include <iostream>
#include "advisorBotMain.h"
#include "csvReader.h"
#include "orderBookEntry.h"

int main()
{
    advisorBotMain app{};
    app.init();
}
