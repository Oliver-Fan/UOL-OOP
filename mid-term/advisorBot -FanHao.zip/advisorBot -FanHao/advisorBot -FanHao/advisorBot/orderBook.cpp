#include "orderBook.h"
#include "csvReader.h"
#include <map>
#include <algorithm>
#include<iostream>


/** construct, reading a csv data file */
orderBook::orderBook(std::string filename)
{
    orders = csvReader::readCSV(filename);
};
/** return vector of all know products in the dataset*/
std::vector<std::string> orderBook::getKnownProducts()
{
    //Vector for storing
    std::vector<std::string> products;

    std::map<std::string,bool> prodMap;

    for(orderBookEntry& e : orders)
    {
        prodMap[e.product] = true;
    };

    for(auto const& e : prodMap)
    {
        products.push_back(e.first);
    };

    return products;
};

std::vector<std::string> orderBook::getKnownTimes()
{
    //Vector for storing
    std::vector<std::string> times;

    std::map<std::string,bool> timeMap;

    for(orderBookEntry& e : orders)
    {
        timeMap[e.timestep] = true;
    };

    for(auto const& e : timeMap)
    {
        times.push_back(e.first);
    };

    return times;
};


/** return vector of Orders according to the sent filters*/
std::vector<orderBookEntry> orderBook:: getOrders(orderBookType type,
                                               std::string product,
                                               std::string timestep)
{
    //Vector for storing
    std::vector<orderBookEntry> orders_sub;
    
    //Loops through orderBookEntry
    for(orderBookEntry& e : orders)
    {
        //If products and type match then add to the vector
        if(e.orderType==type && e.product==product && e.timestep==timestep)
        {
            orders_sub.push_back(e);
        }
    };

    //returns the vector
    return orders_sub;
};

std::vector<orderBookEntry> orderBook:: AdvisorBot(std::string product, orderBookType type)
{
    //Vector for storing
    std::vector<orderBookEntry> advisor;
    
    //Loops through orderBookEntry
    for(orderBookEntry& e : orders)
    {
        //If products and type match then add to the vector
        if(e.product==product && e.orderType==type)
        {
            advisor.push_back(e);
        }
    };

    //returns the vector
    return advisor;
};


double orderBook:: getHighPrice( std::vector<orderBookEntry>& orders)
{
    //Sets max as first price
    double max = orders[0].price;

    //Loops through orders and if price is higher than max, sets it as max
    for(orderBookEntry& e : orders)
    {
        if(e.price > max)
        {
            max=e.price;
        }
    }

    return max;
};


double orderBook:: getLowPrice( std::vector<orderBookEntry>& orders)
{
    //Sets min as first price
    double min = orders[0].price;

    //Loops through orders and if price is higher than min, sets it as min
    for(orderBookEntry& e : orders)
    {
        if(e.price < min)
        {
            min=e.price;
        }
    }
    return min;
};

std::vector<double> orderBook:: getCommonPrice( std::vector<orderBookEntry>& orders)
{
    //Prices
    std::vector<double>Prices;

    //Vector for storing prices with duplicates
    std::map<double, bool> DPrices;

    //Vector for storing prices without duplicates
    std::vector<double> CommonPrices;

    //Loops through orders
    for(int i=0; i<orders.size(); i++)
    {
        //Sets initial count as 1
        int count=1;

        //Loops through orders again and compares the each entry with every other entry
        for(int j=0; j<orders.size(); j++)
        {
            //If 2 entries are the same count is increased by 1
            if (i==j)
            {
                count+=1;
            }
        };

        //If count is greater than 1, that prices is added to the vector
        if(count>1)
        {
            Prices.push_back(orders[i].price);
        }
    };

    //Removing duplicates
    for(double& e : Prices)
    {
        DPrices[e]=true;
    };

    for(auto const& e : DPrices)
    {
        CommonPrices.push_back(e.first);
    };

    return CommonPrices;
};

double orderBook::getTotalOrder(std::vector<orderBookEntry> & orders)
{
    //Sets it as 0
    double total=0;

    //Loops through orders
    for(orderBookEntry& e: orders)
    {
        //Add the price to total at each iteration
        total = total + e.price;
    }

    return total;
};

double orderBook::getTotalVector(std::vector<double> Tot)
{
    //Sets it as 0
    double total=0;

    //Loops through orders
    for(int i=0; i<Tot.size(); i++)
    {
        //Add the price to total at each iteration
        total = total + Tot[i];
    }

    return total;
};

double orderBook::getAverage(std::vector<double> vals)
{
    //Make a double for storing total and get the total using total function
    double Sum = orderBook::getTotalVector(vals);

    //Make a double of size
    double Count = vals.size();

    //Calculate average
    double Average = Sum/Count;

    return Average;
};


std::string orderBook::getEarliestTime()
{
    //Since ascending order so get first timestep
    return orders[0].timestep;
};

std::string orderBook::getNextTime(std::string timestep)
{
    std::string next_timestep="";
    for(orderBookEntry& e : orders)
    {
        if(e.timestep > timestep)
        {
            next_timestep=e.timestep;
            break;
        };
    };

    if(next_timestep=="")
    {
        next_timestep = orders[0].timestep;
    };

    return next_timestep;

};


