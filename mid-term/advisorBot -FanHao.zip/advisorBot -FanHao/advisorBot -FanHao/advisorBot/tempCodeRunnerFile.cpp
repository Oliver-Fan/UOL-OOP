
    // 3 Print product